<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class workexperience extends Model
{
    //
    protected $table = 'workexperience';
    public $timestamps = false;
    public $primaryKey = 'workExperienceId';
}
