<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class freetime extends Model
{
    //
    protected $table = 'freetime';
    public $timestamps = false;
    public $primaryKey = 'id';
}
