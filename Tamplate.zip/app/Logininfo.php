<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class logininfo extends Model
{
    //
    protected $table = 'logininfo';
}
