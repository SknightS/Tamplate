<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class jobtime extends Model
{
    //
    protected $table = 'jobtime';
}
