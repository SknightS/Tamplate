<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hirereport extends Model
{
    //
    protected $table = 'hirereport';
    public $timestamps = false;
    public $primaryKey = 'hireReportId';
}
