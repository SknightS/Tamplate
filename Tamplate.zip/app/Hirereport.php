<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hirereport extends Model
{
    //
    protected $table = 'hirereport';
}
