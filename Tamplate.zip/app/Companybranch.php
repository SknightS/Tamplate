<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class companybranch extends Model
{
    //
    protected $table = 'company_branch';
    public $timestamps = false;
    public $primaryKey = 'id';
}
