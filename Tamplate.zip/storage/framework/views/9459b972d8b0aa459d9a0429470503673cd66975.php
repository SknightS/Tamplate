<div class="candidate-applications-wrapper">

    <?php $__currentLoopData = $allApplication; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applications): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="candidate-application flex no-wrap no-column items-center list-unstyled">



            <div class="candidate-name-cell candidate-cell flex items-center no-column no-wrap">
                <div class="cell-mobile-label">
                    <h6>Image</h6>
                </div> <!-- end .cell-label -->
                <div class="candidate-cell-inner flex items-center no-column no-wrap">
                    <div class="candidate-img">

                        <?php if($applications->image != null): ?>
                            <img src="<?php echo e(url('public/employeeImages/thumb/'.$applications->image)); ?>" height="80px" width="80px" alt="candidate-image" class="img-responsive">
                        <?php else: ?>
                            <img src="<?php echo e(url('public/employeeImages/dummy.jpg')); ?>" height="80px" width="80px" alt="candidate-image" class="img-responsive">
                        <?php endif; ?>


                    </div> <!-- end .candidate-img -->
                    <div class="cell-text no-column">
                        <h4><?php echo e($applications->candidateName); ?></h4>
                    </div> <!-- end .cell-text -->
                </div> <!-- end .candidate-cell-inner -->
            </div> <!-- end .candidate-name-cell -->

            <div class="candidate-job-cell candidate-cell flex no-column no-wrap">
                <div class="cell-mobile-label">
                    <h6>Job</h6>
                </div> <!-- end .cell-label -->
                <div class="cell-text no-column">
                    <h4 style="color: black"><?php echo e($applications->companyName); ?></h4>
                    <p><?php echo e($applications->jobTitle); ?></p>
                </div> <!-- end .candidate-cell-inner -->
            </div> <!-- end .candidate-job-cell -->

            <div class="candidate-resume-cell candidate-cell flex no-column no-wrap">
                <div class="cell-mobile-label">
                    <h6>Email</h6>
                </div> <!-- end .cell-label -->
                <div class="candidate-cell-inner flex no-column no-wrap">
                    <p><span><i class="ion-email"></i></span><?php echo e($applications->candidateEmail); ?></p>
                </div> <!-- end .candidate-cell-inner -->
            </div> <!-- end .candidate-resume-cell -->

            <div class="candidate-resume-cell candidate-cell flex no-column no-wrap">
                <div class="cell-mobile-label">
                    <h6>JobType</h6>
                </div> <!-- end .cell-label -->
                <div class="candidate-cell-inner flex no-column no-wrap">
                    <p><?php echo e($applications->typeName); ?></p>
                </div> <!-- end .candidate-cell-inner -->
            </div> <!-- end .candidate-resume-cell -->

            <div class="candidate-resume-cell candidate-cell flex no-column no-wrap">
                <div class="cell-mobile-label">
                    <h6>Status</h6>
                </div> <!-- end .cell-label -->
                <div class="candidate-cell-inner flex no-column no-wrap">
                    <p>

                        <?php $__currentLoopData = JOB_REQUEST_STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($applications->request_status==$value['code']): ?><?php echo e($value['name']); ?><?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </p>
                </div> <!-- end .candidate-cell-inner -->
            </div> <!-- end .candidate-resume-cell -->

            <div class="candidate-actions-cell candidate-cell flex items-center no-wrap no-column no-wrap">
                <div class="cell-mobile-label">
                    <h6>Actions</h6>
                </div> <!-- end .cell-label -->
                <div class="candidate-cell-inner flex no-column no-wrap">

                    <?php $__currentLoopData = JOB_REQUEST_STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($applications->request_status==$value['code'] && $applications->request_status=='1' ): ?>

                            

                            <a data-panel-id="<?php echo e($applications->requestJobId); ?> "onclick="completeJob(this)"><button class="btn btn-sm btn-success">Complete</button></a>



                        <?php elseif($applications->request_status==$value['code'] && $applications->request_status=='2' ): ?>


                            <a data-panel-id="<?php echo e($applications->requestJobId); ?> "onclick="startJob(this)"><button class="btn btn-sm btn-danger">Start</button></a>



                        <?php elseif($applications->request_status==$value['code'] && $applications->request_status=='5' ): ?>


                            <a data-panel-id="<?php echo e($applications->requestJobId); ?> "onclick="approveJob(this)"><button class="btn btn-sm btn-info">Approve</button></a>
                            <a data-panel-id="<?php echo e($applications->requestJobId); ?> "onclick="rejectJob(this)"><button class="btn btn-sm btn-info">Reject</button></a>


                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div> <!-- end .candidate-cell-inner -->
            </div> <!-- end .candidate-actions-cell -->
        </div> <!-- end .candidate-application -->

        <div class="divider"></div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>




<div class="jobpress-custom-pager list-unstyled flex space-center no-column items-center">

    <?php if($allApplication->currentPage()!= 1): ?>
        <a data-id="<?php echo e($allApplication->previousPageUrl()); ?>" href="javascript:void(0)" class="button pagiNextPrevBtn"><i class="ion-ios-arrow-left"></i>Prev</a>
    <?php endif; ?>
    <ul class="list-unstyled flex no-column items-center pagination">
        <?php for($i=$allApplication->perPage(); $i <= $allApplication->total();$i=($i+$allApplication->perPage())): ?>
            <li ><a href="<?php echo e($allApplication->url($i)); ?>"><?php echo e($i); ?></a></li>
        <?php endfor; ?>
    </ul>
    <?php if($allApplication->lastPage()!=$allApplication->currentPage()): ?>
        <a data-id="<?php echo e($allApplication->nextPageUrl()); ?>"href="javascript:void(0)"  class="button pagiNextPrevBtn">Next<i class="ion-ios-arrow-right"></i></a>
    <?php endif; ?>

</div> <!-- end .jobpress-custom-pager -->

<script>
    $(".pagiNextPrevBtn").on("click",function() {

        var page=$(this).data('id').split('page=')[1];

        getData(page)

    });
</script>