<div class="left-sidebar-menu">
    <ul class="nav nav-pills nav-stacked">
        <li class="heading">Manage account</li>
        <li><a href="<?php echo e(route('resume')); ?>">My Resume</a></li>
        <li><a href="<?php echo e(route('home')); ?>">Staffnetwork Home</a></li>
        
        <li class="nav-divider"></li>
        <li class="heading">Manage job</li>
        
        <li><a href="<?php echo e(route('jobapplied')); ?>">Manage Applications</a></li>
        <li class="nav-divider"></li>
        <li><a  href="<?php echo e(route('changepassword')); ?>">Change Password</a></li>
        <li> <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                Logout
            </a>
        </li>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form>

    </ul>
</div> <!-- end .left-sidebar-menu -->
