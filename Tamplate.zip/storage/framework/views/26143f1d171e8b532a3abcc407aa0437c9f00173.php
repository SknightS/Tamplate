<?php $__env->startSection('emp-contant'); ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
    <h3 class="tab-pane-title">Manage applications</h3>

    

        
        
            
                
                    
                
                
                    
                    
                
            
            
                
            
            
                
            
            
                
                
                
                        
                
                        
                


            
        
            

    



    
        
        
        
        
            
            
            
        
        
        
        
    

    <!--laravel pagination -->
    
        
        
    
    <div class="table table-responsive">
    <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>

        <tr>

            <th>SL</th>
            <th>Job Name</th>
            <th>Company Name</th>
            <th>Job Type</th>
            <th>Apply date</th>
            <th>Job Start Code</th>
            <th>Job End Code</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Job Status</th>

        </tr>
        </thead>
        <tbody>

        <?php
            $count= 1
        ?>
        <?php $__currentLoopData = $candidateAllAppliedJob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allAppliedJob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($count); ?></td>
                <td><?php echo e($allAppliedJob->jobName); ?></td>
                <td><?php echo e($allAppliedJob->companyName); ?></td>
                <td><?php echo e($allAppliedJob->jobType); ?></td>
                <td><?php echo e($allAppliedJob->applyTime); ?></td>

                <td>
                    <?php if($allAppliedJob->request_status=='2'): ?>
                    <?php if(empty($allAppliedJob->jobStartTime)  && empty($allAppliedJob->jobEndTime)): ?>
                    <input style="border: none;background: transparent;" class="passform"  type="password" value="<?php echo e($allAppliedJob->jobStartCode); ?>" readonly />
                    <?php elseif(!empty($allAppliedJob->jobStartTime)  && empty($allAppliedJob->jobEndTime)): ?>
                    job already Running
                    <?php elseif(!empty($allAppliedJob->jobStartTime)  && !empty($allAppliedJob->jobEndTime)): ?>
                    job already End
                    <?php endif; ?>
                    <?php else: ?>
                    <?php endif; ?>

                </td>
                <td>
                    <?php if($allAppliedJob->request_status=='2'): ?>
                        <?php if(empty($allAppliedJob->jobEndTime)): ?>
                    <input style="border: none;background: transparent;" class="passform" type="password" value="<?php echo e($allAppliedJob->jobEndCode); ?>" readonly />
                        <?php else: ?>
                            job already End
                        <?php endif; ?>
                    <?php else: ?>
                    <?php endif; ?>
                </td>
                <td><?php echo e($allAppliedJob->jobStartTime); ?></td>
                <td><?php echo e($allAppliedJob->jobEndTime); ?></td>

                <td>
                    <?php if($allAppliedJob->request_status=='1'): ?>
                    <p class="processing">In process</p>
                    <?php elseif($allAppliedJob->request_status=='0'): ?>
                    <p class="rejected">Rejected</p>
                    <?php elseif($allAppliedJob->request_status=='2'): ?>
                    <p class="approved">Approved</p>
                    <?php endif; ?>
                </td>

                <?php
                    $count++
                ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>
    </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('foot-js'); ?>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>


    <script>

        $(".passform").mousedown(function(){
            $(this).prop('type', 'text');
        });

        $(".passform").mouseup(function(){
            $(this).prop('type', 'password');
        });

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(document).ready( function () {
            $('#example').DataTable({

                "columnDefs": [ {
                    "targets": [ 1,2,3,5,6,9 ],
                    "orderable": false
                } ]
            });
        } );

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('employee.employeDashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>