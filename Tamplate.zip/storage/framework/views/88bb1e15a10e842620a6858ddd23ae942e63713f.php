<div class="bookmarked-jobs-list-wrapper on-listing-page on-job-detals-page">
    <h3>Similar jobs </h3>

    <?php $__currentLoopData = $similarjob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bookmarked-jobs-list-wrapper on-listing-page">
            <div class="bookmarked-job-wrapper">
                <div class="bookmarked-job flex no-wrap no-column ">
                    <div class="job-company-icon">
                        <?php if($sj->cimage != null): ?>
                            <img style="height: 100px;width: 100px" src="<?php echo e(url('public/companyImages/thumb/'.$sj->cimage)); ?>" alt="company-icon" class="img-responsive">
                        <?php else: ?>
                            <img src="<?php echo e(url('public/companyImages/dummy.jpg')); ?>" alt="company-icon" class="img-responsive">
                        <?php endif; ?>

                    </div> <!-- end .job-icon -->
                    <div class="bookmarked-job-info">
                        <h4 class="dark flex no-column"><?php echo e($sj->jobName); ?></h4>
                        <h5><?php echo e($sj->cname); ?></h5>
                        <p><?php echo e($sj->pdes); ?></p>
                        <div class="bookmarked-job-info-bottom flex space-between items-center no-column no-wrap">
                            <div class="bookmarked-job-meta flex items-center no-wrap no-column">
                                
                                
                                
                                
                                
                                <h6 class="bookmarked-job-category"><?php echo e($sj->typeName); ?></h6>
                                <h6 class="candidate-location"><?php echo e($sj->address); ?></h6>
                                <h6 class="hourly-rate"><?php echo e($sj->job_amount); ?><span>/Hour</span></h6>
                            </div> <!-- end .bookmarked-job-meta -->
                            <div class="right-side-bookmarked-job-meta flex items-center no-column no-wrap">
                                
                                <a href="<?php echo e(route('layouts.jobdetails', [ $sj->typeName, $sj->postid] )); ?>" class="button">more detail</a>
                            </div> <!-- end .right-side-bookmarked-job-meta -->
                        </div> <!-- end .bookmarked-job-info-bottom -->
                    </div> <!-- end .bookmarked-job-info -->
                </div> <!-- end .bookmarked-job -->
            </div> <!-- end .bookmarked-job-wrapper -->

        </div> <!-- end .bookmarked-jobs-list-wrapper -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div> <!-- end .bookmarked-jobs-list-wrapper -->

<div class="jobpress-custom-pager list-unstyled flex space-center no-column items-center pagination">
    <?php if($similarjob->currentPage()!= 1): ?>
        <a data-id="<?php echo e($similarjob->previousPageUrl()); ?>" href="<?php echo e($similarjob->previousPageUrl()); ?>" class="button pagiNextPrevBtn"><i class="ion-ios-arrow-left"></i>Prev</a>
    <?php endif; ?>
        
    <ul class="list-unstyled flex no-column items-center pagination">
        <?php for($i=$similarjob->perPage(); $i <= $similarjob->total();$i=($i+$similarjob->perPage())): ?>
            <li <?php if($similarjob->currentPage() == $i): ?> class="page-item active " <?php else: ?> class="page-item" <?php endif; ?> ><a href="<?php echo e($similarjob->url($i)); ?>"><?php echo e($i); ?></a></li>
        <?php endfor; ?>
    </ul>
    <?php if($similarjob->lastPage()!=$similarjob->currentPage()): ?>
        <a data-id="<?php echo e($similarjob->nextPageUrl()); ?>"href="<?php echo e($similarjob->nextPageUrl()); ?>"  class="button pagiNextPrevBtn">Next<i class="ion-ios-arrow-right"></i></a>
    <?php endif; ?>
        
</div>

<script>
    $(".pagiNextPrevBtn").on("click",function() {

        var page=$(this).data('id').split('page=')[1];

        getData(page)

    });
</script>