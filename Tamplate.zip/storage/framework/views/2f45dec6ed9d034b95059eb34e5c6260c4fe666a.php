
<form method="post" action="<?php echo e(route('employee.updateCandidateInfo',$candidateInfo->id)); ?>" enctype="multipart/form-data" class="form-horizontal">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <div class="col-md-6">
        <label class="col-md-2">Name<span style="color: red">*</span></label>
        <input type="text" id="name" name="name" placeholder="Candidate name" value="<?php echo e($candidateInfo->name); ?>" class="form-control col-md-4" required />
        </div>
        <div class="col-md-6">
            <label>Profession<span style="color: red">*</span></label>
            <input type="text" id="profession" name="profession" placeholder="Candidate profession" value="<?php echo e($candidateInfo->professionTitle); ?>" class="form-control" required />
        </div>
    </div>
    <div class="form-group">
    <div class="col-md-6">
        <label class="col-md-2">Phone<span style="color: red">*</span></label>
        <input type="text" id="phone" placeholder="Candidate Phone" name="phone" value="<?php echo e($candidateInfo->phone); ?>" class="form-control col-md-4" required />
    </div>
    <div class="col-md-6">
        <label class="col-md-2">Email<span style="color: red">*</span></label>
        <input type="email" id="email" placeholder="Candidate email" name="email" value="<?php echo e($candidateInfo->email); ?>" class="form-control col-md-4" required />
    </div>
    </div>
    <div align="center" class="form-group">
        <label style="text-align: center">Address</label>
    </div>

    <div  class="form-group">
        <div class="col-md-6">
        <label class="col-md-2">States</label>
        <select class="form-control col-md-4" id="states" name="states">
            <option selected value="">Select States</option>

            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($candidateInfo->address !=null): ?>
                    <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addresss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if($addresss->stateId==$state->id): ?> selected <?php endif; ?>  value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <option  value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
        <div class="col-md-6">
        <label class="col-md-2">City</label>
        <select class="form-control col-md-4" id="cities" name="cities">
            <option selected value="">Select City</option>
            <?php if($candidateInfo->address !=null): ?>
                <option selected  value="<?php echo e($addresss->cityId); ?>"><?php echo e($addresss->city); ?></option>
            <?php endif; ?>
        </select>
        </div>

    </div>
    <div  class="form-group">
        <div class="col-md-12">
        <label >Address</label>
            <?php if($candidateInfo->address !=null): ?>
                <textarea class="form-control" id="address"name="address" rows="2"cols="5" placeholder="Your address"><?php echo e($addresss->addresscol); ?></textarea>
            <?php else: ?>
                <textarea class="form-control" id="address"name="address" rows="2"cols="5" placeholder="Your address"></textarea>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">

        <div class="col-md-6">

        <label class="col-md-2">Image</label>
        <input type="file" id="image" name="image" accept="image/*" placeholder="Candidate image" class="form-control col-md-4" />
        </div>

    </div>


    <div style="padding: 20px;text-align: center" class="row">
        <button type="submit" class="btn btn-info">Submit</button>
        <button type="button"  data-dismiss="modal" class="btn btn-danger">Cancel</button>
    </div>

</form>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#states').change(function(){

        var states=$('#states').val();

        $.ajax({
            type: "POST",
            url: '<?php echo e(route('employee.getAllAddressCity')); ?>',
            data: {stateId:states},
            success: function(data){

                document.getElementById("cities").innerHTML = data;

            },
        });

    });
</script>


