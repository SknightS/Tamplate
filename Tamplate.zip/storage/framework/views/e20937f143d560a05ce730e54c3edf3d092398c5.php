
<?php $__currentLoopData = $employerCompaniesWithBranch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="post" action="" enctype="multipart/form-data" class="form-horizontal">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <div class="col-md-12">
            <label class="col-md-2">Name<span style="color: red">*</span></label>
            <input type="text" id="name" name="name" placeholder="Company name" value="<?php echo e($company->branchName); ?>" class="form-control col-md-4" required />
        </div>
    </div>
    <div class="form-group">
        <div class="col-md-6">
            <label class="col-md-2">Phone<span style="color: red">*</span></label>
            <input type="text" id="phone" placeholder="Company Phone" name="phone" value="<?php echo e($company->phone); ?>" class="form-control col-md-4" required />
        </div>
        <div class="col-md-6">
            <label class="col-md-2">Email<span style="color: red">*</span></label>
            <input type="email" id="email" placeholder="Company email" name="email" value="<?php echo e($company->email); ?>" class="form-control col-md-4" required />
        </div>
    </div>
    <div align="center" class="form-group">
        <label style="text-align: center">Address</label>
    </div>

    <div  class="form-group">
        <div class="col-md-6">
            <label class="col-md-2">States<span style="color: red">*</span></label>
            <select class="form-control col-md-4" id="states" name="states" required>
                <option selected value="">Select States</option>

                <?php $__currentLoopData = $addressStates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($company->state !=null): ?>

                        <option <?php if($company->state==$state->id): ?> selected <?php endif; ?>  value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>

                    <?php else: ?>
                        <option  value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-6">
            <label class="col-md-2">City<span style="color: red">*</span></label>
            <select class="form-control col-md-4" id="cities" name="cities"required>
                <option selected value="">Select City</option>
                <?php if($company->cityId !=null): ?>
                    <option selected  value="<?php echo e($company->cityId); ?>"><?php echo e($company->cityName); ?></option>
                <?php endif; ?>
            </select>
        </div>

    </div>
    <div  class="form-group">
        <div class="col-md-12">
            <label >Address<span style="color: red">*</span></label>
            <?php if($company->addresscol !=null): ?>
                <textarea class="form-control" id="address"name="address" rows="2"cols="5" placeholder="Your address"><?php echo e($company->addresscol); ?></textarea>
            <?php else: ?>
                <textarea class="form-control" id="address"name="address" rows="2"cols="5" placeholder="Your address"></textarea>
            <?php endif; ?>
        </div>
    </div>



    <div class="row">

        <div class="col-md-6">

            <label class="col-md-2">Image</label>
            <input type="file" id="image" name="image" accept="image/*" placeholder="Candidate image" class="form-control col-md-4" />
        </div>

    </div>


    <div style="padding: 20px;text-align: center" class="row">
        <button type="submit" class="btn btn-info">Submit</button>
        <button type="button"  data-dismiss="modal" class="btn btn-danger">Cancel</button>
    </div>

</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#states').change(function(){

        var states=$('#states').val();

        $.ajax({
            type: "POST",
            url: '<?php echo e(route('employer.getAllAddressCity')); ?>',
            data: {stateId:states},
            success: function(data){

                document.getElementById("cities").innerHTML = data;

            },
        });

    });


</script>


