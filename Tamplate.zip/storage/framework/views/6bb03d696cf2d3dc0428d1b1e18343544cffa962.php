
<?php $__currentLoopData = $candidateInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="post" action="<?php echo e(route('employee.updateCandidateAboutMe',$id)); ?>" class="form-horizontal">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <div class="col-md-12">
            <label >About Me<span style="color: red">*</span></label>
            <textarea id="aboutMe" placeholder="Candidate about me" name="aboutMe" class="form-control" required rows="4" cols="50"><?php echo e($candidate->aboutme); ?></textarea>
        </div>
    </div>

    <div style="padding: 20px;text-align: center" class="row">
        <button type="submit" class="btn btn-info">Submit</button>
        <button type="button"  data-dismiss="modal" class="btn btn-danger">Cancel</button>
    </div>

</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



