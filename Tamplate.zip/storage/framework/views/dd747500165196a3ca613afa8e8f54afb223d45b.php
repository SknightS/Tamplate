<?php $__env->startSection('empr-contant'); ?>


    <div class="profile-badge"><h6>My Profile</h6></div>
    <div class="profile-wrapper">

        <div class="profile-info profile-section flex no-column no-wrap">

            <div class="profile-picture">
                <?php if($employerInfo->image != null): ?>
                    <img src="<?php echo e(url('public/employerImages/thumb/'.$employerInfo->image)); ?>" height="116px" width="116px" alt="employer-picture" class="img-responsive">
                <?php else: ?>
                    <img src="<?php echo e(url('public/employerImages/dummy.jpg')); ?>" height="116px" width="116px" alt="employer-picture" class="img-responsive">
                <?php endif; ?>
            </div> <!-- end .user-picture -->
            <div class="profile-meta">
                <h4 class="dark"><?php echo e($employerInfo->contact_person_name); ?><span><a style="cursor: pointer" onclick="editEmployer()"><i class="ion-edit"></i></a></span></h4>

                <div class="profile-contact flex items-center no-wrap no-column">
                    <?php if($employerAddress!=null): ?>
                        <?php $__currentLoopData = $employerAddress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h6 class="contact-location"><?php echo e($address->addresscol); ?>,<span><?php echo e($address->city); ?>, <?php echo e($address->state); ?></span></h6>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <h6 class="contact-location"><span></span></h6>
                    <?php endif; ?>
                    <h6 class="contact-phone"><?php echo e($employerInfo->cp_phone); ?></h6>
                    <h6 class="contact-email"><?php echo e($employerInfo->cp_email); ?></h6>
                </div> <!-- end .profile-contact -->

            </div> <!-- end .profile-meta -->
        </div> <!-- end .profile-info -->

        

        
            
            
        


        

            


        </div> <!-- end .profile-skills-wrapper -->

    </div> <!-- end .profile-wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot-js'); ?>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $(document).ready(function(){
            <?php if(Session::has('success_msg')): ?>
            $.alert({
                title: 'Success!',
                type: 'green',
                content: '<?php echo e(Session::get('success_msg')); ?>',
                buttons: {
                    tryAgain: {
                        text: 'Ok',
                        btnClass: 'btn-green',
                        action: function () {
                        }
                    }
                }
            });
            <?php endif; ?>
        });
        function editEmployer() {
            var id= '<?php echo e($employerInfo->companyId); ?>';
            var name = '<?php echo e($employerInfo->contact_person_name); ?>';

            var phone = '<?php echo e($employerInfo->cp_phone); ?>';
            var email = '<?php echo e($employerInfo->cp_email); ?>';
            var addressId = '<?php echo e($employerInfo->address_addressId); ?>';

            $.ajax({
                type: "POST",
                url: '<?php echo e(route('employer.showInfo')); ?>',
                data: {name:name,phone:phone,email:email,id:id,address:addressId},
                success: function(data){
                    $('.modal-body').html(data);
                    $('#myModalLabel').html("Edit-Employer Info!");
                    $('#myModal').modal({show:true});

                },
            });
        }
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('employer.employerDashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>