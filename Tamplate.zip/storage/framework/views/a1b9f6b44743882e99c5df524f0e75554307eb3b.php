<div class="left-sidebar-menu">
    <ul class="nav nav-pills nav-stacked">
        <li class="heading">Manage account</li>

        <li><a  href="<?php echo e(route('employer.profile')); ?>">My Profile</a></li>
        <li><a href="<?php echo e(route('home')); ?>">Staffnetwork Home</a></li>
        <li ><a href="<?php echo e(route('employer.companyInfo')); ?>">Company Info</a></li>
        <li class="nav-divider"></li>
        <li class="heading">Manage job</li>
        
        <li><a  href="<?php echo e(route('employer.manageAllApplication')); ?>">Manage Applications</a></li>
        <li><a  href="<?php echo e(route('employer.manageAllJob')); ?>">Manage Jobs</a></li>
        
        <li class="nav-divider"></li>
        
        <li> <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                Logout
            </a></li>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form>


    </ul>
</div> <!-- end .left-sidebar-menu -->