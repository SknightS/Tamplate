<div class="table-header">
    <div class="table-cells flex">
        <div class="job-title-cell"><h6>Job title / Company name</h6></div>
        <div class="job-type-cell"><h6>Type</h6></div>
        <div class="location-cell"><h6>Location</h6></div>
        <div class="expired-date-cell"><h6>Expired Dated</h6></div>
        <div class="salary-cell"><h6>Salary</h6></div>
    </div> <!-- end .table-cells -->
</div> <!-- end .table-header -->

<?php $__currentLoopData = $latestjobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="table-row">
        <div class="table-cells flex no-wrap">
            <div class="cell job-title-cell flex no-column no-wrap">
                <div class="cell-mobile-label">
                    <h6>Company name</h6>
                </div> <!-- end .cell-label -->
                <img src="<?php echo e(url('public/images/company-logo01.jpg')); ?>" alt="company-logo" class="img-responsive">
                <div class="content">
                    <h4>
                        
                        <a href="<?php echo e(route('layouts.jobdetails', [$lj->typeName,$lj->postId] )); ?>"><?php echo e($lj->jobName); ?></a>
                    </h4>
                    <p class="small"><?php echo e($lj->cname); ?></p>
                </div> <!-- end .content -->
            </div> <!-- end .job-title-cell -->
            <div class="cell location-cell flex no-column no-wrap">
                <div class="cell-mobile-label">
                    <h6>Type</h6>
                </div> <!-- end .cell-label -->
                <p><?php echo e($lj->typeName); ?></p>
            </div> <!-- end .job-type-cell -->
            <div class="cell location-cell flex no-column no-wrap">
                <div class="cell-mobile-label">
                    <h6>Location</h6>
                </div> <!-- end .cell-label -->
                <p><?php echo e($lj->cityname." , ".$lj->statename); ?></p>
            </div> <!-- end .location-cell -->
            <div class="cell expired-date-cell flex no-column no-wrap">
                <div class="cell-mobile-label">
                    <h6>Expired Date</h6>
                </div> <!-- end .cell-label -->
                <p><?php echo e($lj->deadline); ?></p>
            </div> <!-- end .expire-date-cell -->
            <div class="cell salary-cell flex no-column no-wrap">
                <div class="cell-mobile-label">
                    <h6>Salary</h6>
                </div> <!-- end .cell-label -->
                <p><?php echo e($lj->job_amount."/HOUR"); ?></p>
            </div> <!-- end .salray-cell -->
        </div> <!-- end .table-cells -->
    </div> <!-- end .table-row -->



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>












































































































































































<div class="table-footer flex space-between items-center">
    <h6>showing
        <span><?php echo e(($latestjobs->currentpage()-1)*$latestjobs->perpage()+1); ?>

            - <?php echo e((($latestjobs->currentpage()-1)*$latestjobs->perpage())+$latestjobs->count()); ?>

                                </span>of
        <span><?php echo e($latestjobs->total()); ?></span>Jobs</h6>



    <div class="jobpress-custom-pager list-unstyled flex space-between no-column items-center">

        <?php if($latestjobs->currentPage()!= 1): ?>
            <a data-id="<?php echo e($latestjobs->previousPageUrl()); ?>" href="javascript:void(0)" class="button pagiNextPrevBtn"><i class="ion-ios-arrow-left"></i>Prev</a>
        <?php endif; ?>


            <ul class="list-unstyled flex no-column items-center pagination">
            <?php for($i=$latestjobs->perPage(); $i <= $latestjobs->total();$i=($i+$latestjobs->perPage())): ?>
                <li <?php if($latestjobs->currentPage() == $i): ?> class="page-item active " <?php else: ?> class="page-item" <?php endif; ?> ><a href="<?php echo e($latestjobs->url($i)); ?>"><?php echo e($i); ?></a></li>
            <?php endfor; ?>
        </ul>
        <?php if($latestjobs->lastPage()!=$latestjobs->currentPage()): ?>
            <a data-id="<?php echo e($latestjobs->nextPageUrl()); ?>"href="javascript:void(0)"  class="button pagiNextPrevBtn">Next<i class="ion-ios-arrow-right"></i></a>
        <?php endif; ?>



    </div>
    


</div> <!-- end .jobpress-custom-pager -->

<script>
    $(".pagiNextPrevBtn").on("click",function() {

        var page=$(this).data('id').split('page=')[1];

        getData(page)

    });
</script>