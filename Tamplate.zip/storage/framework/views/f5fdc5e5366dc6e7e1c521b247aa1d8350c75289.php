<header class="header">
    <div class="container clearfix">
        <div class="header-inner flex space-between items-center">
            <div class="left">
                <div class="logo"><a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(url('public/images/logo.png')); ?>" alt="JobPress" width="250" height="100" class="img-responsive"></a></div>
            </div> <!-- end .left -->
            <div class="right flex space-between no-column items-center">
                <div class="navigation">
                    <nav class="main-nav">
                        <ul class="list-unstyled">
                            <li class="active"><a href="<?php echo e(route('home')); ?>">Home</a></li>

                            <li class="menu-item">


                                <a href="<?php echo e(route('allCandidate')); ?>"> Candidates</a>

                            </li>
                            <li class="menu-item">
                                <a href="<?php echo e(route('Companies')); ?>">Companies</a>

                            </li>

                        </ul>
                    </nav> <!-- end .main-nav -->
                    <a href="#" class="responsive-menu-open"><i class="ion-navicon"></i></a>
                </div> <!-- end .navigation -->

                <?php if(Auth::check()): ?>


                <?php if(UserType['admin']['code']== Auth::user()->fkuserTypeId || UserType['empr']['code']== Auth::user()->fkuserTypeId ): ?>
                    <a href="<?php echo e(route('postJob')); ?>" class="button">Post a Job</a>
                    <a href="<?php echo e(route('employer.profile')); ?>" class="button">Profile</a>

                    <a href="<?php echo e(route('logout')); ?>" class="button" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            Logout
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>

                <?php elseif(UserType['emp']['code']== Auth::user()->fkuserTypeId): ?>

                    <a href="<?php echo e(route('employee')); ?>" class="button">Profile</a>

                    <a href="<?php echo e(route('logout')); ?>" class="button" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            Logout
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>

                <?php endif; ?>

                <?php endif; ?>

                <?php if(!Auth::check()): ?>
                    <div class="button-group-merged flex no-column">

                        <a href="<?php echo e(route('sigupShow')); ?>" class="button">Sign up</a>
                        <a href="<?php echo e(route('loginshow')); ?>" class="button"  data-target=".bs-modal-sm">Sign in</a>
                    </div> <!-- end .button-group-merged -->
                <?php endif; ?>



            </div> <!-- end .right -->
        </div> <!-- end .header-inner -->
    </div> <!-- end .container -->
</header>