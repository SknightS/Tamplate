<?php $__env->startSection('content'); ?>
    <!-- Responsive Menu -->
    <div class="responsive-menu">
        <a href="#" class="responsive-menu-close"><i class="ion-android-close"></i></a>
        <nav class="responsive-nav"></nav> <!-- end .responsive-nav -->
    </div> <!-- end .responsive-menu -->

    <!-- Breadcrumb Bar -->
    <div class="section breadcrumb-bar solid-blue-bg">
        <div class="inner">
            <div class="container">
                <div class="breadcrumb-menu flex items-center no-column">

                    <?php if($companyDetails->image != null): ?>
                        <img src="<?php echo e(url('public/employerImages/thumb/'.$companyDetails->image)); ?>" alt="company-logo" class="img-responsive">
                    <?php else: ?>
                        <img src="<?php echo e(url('public/employeeImages/dummy.jpg')); ?>" alt="company-logo" class="img-responsive">
                    <?php endif; ?>

                    <div class="breadcrumb-info-dashboard">
                        <h2><?php echo e($companyDetails->name); ?></h2>

                        <?php if($companyAddress!=null): ?>
                            <?php $__currentLoopData = $companyAddress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h4 ><?php echo e($address->addresscol); ?>,<span><?php echo e($address->city); ?>, <?php echo e($address->state); ?></span></h4>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <h4 ><span></span></h4>
                        <?php endif; ?>


                    </div> <!-- end .candidate-info -->
                </div> <!-- end .breadcrumb-menu -->
            </div> <!-- end .container -->
        </div> <!-- end .inner -->
    </div> <!-- end .section -->

    <!-- Employer Dashboard -->
    <div class="section employer-dashboard-content solid-light-grey-bg">
        <div class="inner">
            <div class="container">

                <div class="right-side-content ">

                    <div id="profile" class="tab-pane  fade in active">

                        <div class="profile-wrapper fade in active">

                            <div class="profile-info profile-section flex no-column no-wrap">
                                <div class="profile-picture">
                                                                           
                                </div> <!-- end .user-picture -->
                                <div class="profile-meta">
                                    <h4 class="dark"><?php echo e($companyDetails->name); ?></h4>
                                    <?php if($companyAddress!=null): ?>
                                        <?php $__currentLoopData = $companyAddress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p ><?php echo e($address->addresscol); ?>,<span><?php echo e($address->city); ?>, <?php echo e($address->state); ?></span></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <p ><span></span></p>
                                    <?php endif; ?>

                                    
                                    <div class="profile-contact flex items-center no-wrap no-column">
                                        <h6 class="contact-phone"><?php echo e($companyDetails->phone); ?></h6>
                                        <h6 class="contact-email"><?php echo e($companyDetails->email); ?></h6>
                                    </div> <!-- end .profile-contact -->

                                    
                                        
                                        
                                        
                                    

                                </div> <!-- end .profile-meta -->
                            </div> <!-- end .profile-info -->

                            <div class="divider"></div>

                            <div class="profile-about profile-section">
                                <h3 class="dark profile-title">About company</h3>
                                <p><?php echo e($companyDetails->about); ?></p>
                            </div> <!-- end .profile-about -->

                            <div class="divider"></div>

                            
                                
                                
                                    
                                        
                                        
                                        
                                        
                                        
                                    
                                
                                
                                
                                    
                                        
                                        
                                        
                                        
                                        
                                    
                                
                            

                        </div> <!-- end .profile-wrapper -->
                    </div> <!-- end #profile-tab -->

                </div> <!-- end .right-side-content -->

            </div> <!-- end .container -->
        </div> <!-- end .inner -->
    </div> <!-- end .section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>