<div class="sort-by-wrapper on-listing-page flex space-between items-center no-wrap">
    <div class="left-side-inner">
        <h6>showing
            <span><?php echo e(($alljob->currentpage()-1)*$alljob->perpage()+1); ?>

                - <?php echo e((($alljob->currentpage()-1)*$alljob->perpage())+$alljob->count()); ?>

                                </span>of
            <span><?php echo e($alljob->total()); ?></span>Jobs</h6>
    </div> <!-- end .left-side -->
    <div class="right-side-inner">
        <div class="sort-by dropdown flex no-wrap no-column items-center">
            <h6>sort by</h6>
            <button class="button dropdown-toggle" type="button" id="sort-by" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Default
                <i class="ion-ios-arrow-down"></i>
            </button>
            <ul class="dropdown-menu" aria-labelledby="sort-by">
                <li><a href="#">Featured</a></li>
                <li><a href="#">Top candidates</a></li>
                <li><a href="#">Price, high to low</a></li>
                <li><a href="#">Alphabetically, A-Z</a></li>
                <li><a href="#">Alphabetically, Z-A</a></li>
                <li><a href="#">Best sellers</a></li>
            </ul> <!-- end .dropdown-menu -->
        </div> <!-- end .sort-by-drop-down -->
    </div> <!-- end .right-side -->
</div> <!-- end .sort-by-wrapper -->

<?php $__currentLoopData = $alljob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bookmarked-jobs-list-wrapper on-listing-page">
        <div class="bookmarked-job-wrapper">
            <div class="bookmarked-job flex no-wrap no-column ">
                <div class="job-company-icon">
                    <?php if($aj->image != null): ?>
                        <img src="<?php echo e(url('public/companyImages/thumb/'.$aj->cImage)); ?>" alt="company-icon" class="img-responsive">
                    <?php else: ?>
                        <img src="<?php echo e(url('public/companyImages/dummy.jpg')); ?>" alt="company-icon" class="img-responsive">
                    <?php endif; ?>

                    
                </div> <!-- end .job-icon -->
                <div class="bookmarked-job-info">
                    <h4 class="dark flex no-column"><?php echo e($aj->jobName); ?></h4>
                    <h5><?php echo e($aj->cname); ?></h5>
                    <p><?php echo e($aj->pdes); ?></p>
                    <div class="bookmarked-job-info-bottom flex space-between items-center no-column no-wrap">
                        <div class="bookmarked-job-meta flex items-center no-wrap no-column">
                            
                            
                            
                            
                            
                            <h6 class="bookmarked-job-category"><?php echo e($aj->typeName); ?></h6>
                            <h6 class="candidate-location"><?php echo e($aj->address); ?></h6>
                            <h6 class="hourly-rate"><?php echo e($aj->job_amount); ?><span>/Hour</span></h6>
                        </div> <!-- end .bookmarked-job-meta -->
                        <div class="right-side-bookmarked-job-meta flex items-center no-column no-wrap">
                            
                            <a href="<?php echo e(route('layouts.jobdetails', [ $aj->typeName, $aj->postid] )); ?>" class="button">more detail</a>
                        </div> <!-- end .right-side-bookmarked-job-meta -->
                    </div> <!-- end .bookmarked-job-info-bottom -->
                </div> <!-- end .bookmarked-job-info -->
            </div> <!-- end .bookmarked-job -->
        </div> <!-- end .bookmarked-job-wrapper -->

    </div> <!-- end .bookmarked-jobs-list-wrapper -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="jobpress-custom-pager list-unstyled flex space-center no-column items-center pagination">
    <?php if($alljob->currentPage()!= 1): ?>
        <a data-id="<?php echo e($alljob->previousPageUrl()); ?>" href="<?php echo e($alljob->previousPageUrl()); ?>" class="button pagiNextPrevBtn"><i class="ion-ios-arrow-left"></i>Prev</a>
    <?php endif; ?>

    <ul class="list-unstyled flex no-column items-center pagination">
        <?php for($i=$alljob->perPage(); $i <= $alljob->total();$i=($i+$alljob->perPage())): ?>
            <li  ><a href="<?php echo e($alljob->url($i)); ?>"><?php echo e($i); ?></a></li>
        <?php endfor; ?>
    </ul>
    <?php if($alljob->lastPage()!=$alljob->currentPage()): ?>
        <a data-id="<?php echo e($alljob->nextPageUrl()); ?>"href="<?php echo e($alljob->nextPageUrl()); ?>"  class="button pagiNextPrevBtn">Next<i class="ion-ios-arrow-right"></i></a>
    <?php endif; ?>

</div>

<script>
    $(".pagiNextPrevBtn").on("click",function() {

        var page=$(this).data('id').split('page=')[1];

        getData(page)

    });
</script>