<?php $__env->startSection('emp-contant'); ?>

    <div class="password-form-wrapper">
        <h3 class="dark">Change Password</h3>
        <form class="password-form">
            <div class="form-group">
                <label for="InputEmail1">Old password<sup>*</sup></label>
                <input type="email" class="form-control" id="InputEmail1" placeholder="">
            </div>

            <div class="form-group">
                <label for="InputPassword1">New Password<sup>*</sup></label>
                <input type="password" class="form-control" id="InputPassword1" placeholder="">
            </div>

            <div class="form-group">
                <label for="InputPassword1">Confirm New Password<sup>*</sup></label>
                <input type="password" class="form-control" id="InputPassword1" placeholder="">
            </div>
        </form> <!-- end .password-form -->
        <div class="password-button-wrapper">
            <button type="submit" class="button">Save change</button>
        </div> <!-- end .password-button-wrapper -->
    </div> <!-- end .password-form-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('employee.employeDashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>