
<form method="post" action="<?php echo e(route('employer.insertNewJob')); ?>"  class="form-horizontal">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <div class="col-md-6">
            <label class="col-md-6">company Name<span style="color: red">*</span></label>
            <select class="form-control col-md-4" id="companyId" name="companyId" required>
                <option selected value="">Select Company</option>

                <?php $__currentLoopData = $companyBrach; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option  value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-6">
            <label class="col-md-4">Job Name<span style="color: red">*</span></label>
            <input type="text" id="jobName" name="jobName" placeholder="Job name" class="form-control col-md-4" required />
        </div>
    </div>
    <div class="form-group">
        <div class="col-md-6">
            <label class="col-md-4">job Type<span style="color: red">*</span></label>
            <select class="form-control col-md-4" id="jobType" name="jobType" required>
                <option selected value="">Select type</option>

                <?php $__currentLoopData = $jobType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option  value="<?php echo e($jobT->id); ?>"><?php echo e($jobT->typeName); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-6">
            <label class="col-md-4">DeadLine<span style="color: red">*</span></label>
            <input type="text" id="deadLine" name="deadLine" class="form-control col-md-4 dateTime" required />
        </div>
    </div>
    <div class="form-group">
        <div class="col-md-6">
            <label class="col-md-2">Vacancy<span style="color: red">*</span></label>
            <input type="number" id="vacancy" placeholder="Vacancy" name="vacancy"  class="form-control col-md-4" required />
        </div>
        <div class="col-md-6">
            <label class="col-md-4">job Amount<span style="color: red">*</span></label>
            <input type="number" id="jobAmount" placeholder="Amount" name="jobAmount"  class="form-control col-md-4" required />
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-6">
            <label class="col-md-4">job Status<span style="color: red">*</span></label>
            <select class="form-control col-md-4" id="jobStatus" name="jobStatus" onchange="checkPost()" required>
                <option selected value="">Select status</option>

                <?php $__currentLoopData = JOB_STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($value['code'] !='0'): ?>
                    <option value="<?php echo e($value['code']); ?>"><?php echo e($key); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>
        <div class="col-md-6">

        </div>
    </div>



    <div id="postDesc" class="form-group">
        <div class="col-md-12">
            <label >Post Description</label>
            <textarea class="form-control" id="postDescription"name="postDescription" rows="3"cols="5" placeholder="Post Description"></textarea>

        </div>
    </div>
    <div  class="form-group">
        <div class="col-md-12">
            <label >Job Description<span style="color: red">*</span></label>
            <textarea class="form-control" id="description"name="description" rows="3"cols="5" required placeholder="Description"></textarea>

        </div>
    </div>
    <div  class="form-group">
        <div class="col-md-12">
        <button class="btn btn-sm btn-success" type="submit">Submit</button>
        </div>
    </div>


</form>

<style>
    .modal-dialog{
        width:70%;

    }
</style>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $( function() {
        $( '#postDesc' ).hide();
        $("[name='postDescription']").prop("required", false);

        $(".dateTime").datetimepicker({
            format: "YYYY-MM-DD",

        });

    });
    function checkPost() {
        if ($("#jobStatus").val()== '<?php echo JOB_STATUS['post']['code'] ?>' ){


            $( '#postDesc' ).show();
            $("[name='postDescription']").prop("required", true);

        }else {

            $( '#postDesc' ).hide();
            $("[name='postDescription']").prop("required", false);
        }

    }



</script>
