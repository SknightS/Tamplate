<?php $__env->startSection('content'); ?>
    <!-- Responsive Menu -->
    <div class="responsive-menu">
        <a href="#" class="responsive-menu-close"><i class="ion-android-close"></i></a>
        <nav class="responsive-nav"></nav> <!-- end .responsive-nav -->
    </div> <!-- end .responsive-menu -->

    <!-- Breadcrumb Bar -->
    <div class="section breadcrumb-bar solid-blue-bg">
        <div class="inner">
            <div class="container">
                <div class="breadcrumb-menu flex items-center no-column">

                    <?php if($candidateInfo->image != null): ?>
                        <img src="<?php echo e(url('public/employeeImages/thumb/'.$candidateInfo->image)); ?>" alt="avatar" class="img-responsive">
                    <?php else: ?>
                        <img src="<?php echo e(url('public/employeeImages/dummy.jpg')); ?>" alt="avatar" class="img-responsive">
                    <?php endif; ?>
                    <div class="breadcrumb-info-dashboard">
                        <h2><?php echo e($candidateInfo->name); ?></h2>
                        <h4><?php echo e($candidateInfo->professionTitle); ?></h4>
                    </div> <!-- end .candidate-info -->


                </div> <!-- end .breadcrumb-menu -->
            </div> <!-- end .container -->
        </div> <!-- end .inner -->
    </div> <!-- end .section -->

    <!-- Employer Dashboard -->
    <div class="section employer-dashboard-content solid-light-grey-bg">
        <div class="inner">
            <div class="container">

                <div class="right-side-content ">

                    <div id="profile" class="tab-pane  fade in active">

                        <div class="profile-wrapper fade in active">


                            <div class="profile-badge"><h6>My resume</h6></div>
                            <div class="profile-wrapper">

                                <div class="profile-info profile-section flex no-column no-wrap">

                                    <div class="profile-picture">
                                        <?php if($candidateInfo->image != null): ?>
                                            <img src="<?php echo e(url('public/employeeImages/thumb/'.$candidateInfo->image)); ?>" height="116px" width="116px" alt="candidate-picture" class="img-responsive">
                                        <?php else: ?>
                                            <img src="<?php echo e(url('public/employeeImages/dummy.jpg')); ?>" height="116px" width="116px" alt="candidate-picture" class="img-responsive">
                                        <?php endif; ?>
                                    </div> <!-- end .user-picture -->
                                    <div class="profile-meta">
                                        <h4 class="dark"><?php echo e($candidateInfo->name); ?></h4>

                                        <p><?php echo e($candidateInfo->professionTitle); ?></p>
                                        <div class="profile-contact flex items-center no-wrap no-column">
                                            <?php if($employeeAddress!=null): ?>
                                                <?php $__currentLoopData = $employeeAddress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <h6 class="contact-location"><?php echo e($address->addresscol); ?>,<span><?php echo e($address->city); ?>, <?php echo e($address->state); ?></span></h6>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <h6 class="contact-location"><span></span></h6>
                                            <?php endif; ?>
                                            <h6 class="contact-phone"><?php echo e($candidateInfo->phone); ?></h6>
                                            <h6 class="contact-email"><?php echo e($candidateInfo->email); ?></h6>
                                        </div> <!-- end .profile-contact -->
                                        <div>

                                            <ul class="list-unstyled social-icons flex no-column">
                                                <?php $__currentLoopData = $socialLink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialLinks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e($socialLinks->link); ?>"><?php echo e($socialLinks->name); ?></a>

                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </ul> <!-- end .social-icons -->
                                        </div>
                                    </div> <!-- end .profile-meta -->
                                </div> <!-- end .profile-info -->

                                <div class="divider"></div>

                                <div class="profile-about profile-section">
                                    <h3 class="dark profile-title">About me</h3>
                                    <p><?php echo e($candidateInfo->aboutme); ?></p>
                                </div> <!-- end .profile-about -->

                                <div class="divider"></div>

                                <div id="workExperience" class="profile-experience-wrapper profile-section">
                                    <h3 class="dark profile-title">Work experience</h3>
                                    <?php $__currentLoopData = $workExperience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workingExp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="profile-experience flex space-between no-wrap no-column">
                                            <div class="profile-experience-left">
                                                <h5 class="profile-designation dark"><?php echo e($workingExp->postName); ?></h5>
                                                <h5 class="profile-company dark"><?php echo e($workingExp->comapnyName); ?></h5>
                                                <p class="small ultra-light"><?php echo e($workingExp->duration); ?></p>
                                                <p><?php echo e($workingExp->description); ?></p>
                                                
                                            </div> <!-- end .profile-experience-left -->
                                            
                                            
                                            
                                        </div> <!-- end .profile-experience -->
                                        <div class="spacer-md"></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div> <!-- end .profile-experience-wrapper -->

                                <div class="divider"></div>

                                <div id="Education" class="profile-education-wrapper profile-section">
                                    <h3 class="dark profile-title">Education</h3>
                                    <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="profile-education">
                                            <h5 class="dark"><?php echo e($edu->schoolName); ?>&nbsp;</h5>
                                            <p><?php echo e($edu->degreeName); ?></p>
                                            <p class="ultra-light"><?php echo e($edu->startDate); ?> - <?php if($edu->currentlyRunning=='0'): ?><?php echo e($edu->endDate); ?><?php else: ?><?php echo e("Currenty Running"); ?><?php endif; ?></p>
                                        </div> <!-- end .profile-education -->
                                        <div class="spacer-md"></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div> <!-- end .profile-education-wrapper -->

                                <div class="divider"></div>

                                <div id="Skill" class="profile-skills-wrapper profile-section">
                                    <h3 class="dark profile-title">Summary skill</h3>
                                    <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personalSkill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="progress-wrapper flex space-between items-center no-wrap">
                                            <h6 class="progress-skill"><?php echo e($personalSkill->skillName); ?></h6>
                                            <div class="progress">
                                                <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo e($personalSkill->percentage); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($personalSkill->percentage); ?>%;">
                                                </div> <!-- end .progress-bar -->
                                            </div> <!-- end .progress -->
                                            <h6 class="percentage"><span class="countTo" data-from="0" data-to="<?php echo e($personalSkill->percentage); ?>"><?php echo e($personalSkill->percentage); ?></span>%</h6>

                                        </div> <!-- end .progress-wrapper -->

                                        <div class="spacer-xs"></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    
                                </div> <!-- end .profile-skills-wrapper -->

                                <div class="divider"></div>

                                <div id="FreeTime" class="profile-skills-wrapper profile-section">
                                    <h3 class="dark profile-title">Free Time</h3>

                                    <div class="table table-responsive">
                                        <table class="table table-bordered">
                                            <thead>
                                            <th>Day</th>
                                            <th>Start Time</th>
                                            <th>End Time</th>

                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $FreeTimeInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $FreeTime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($FreeTime->day); ?></td>
                                                    <td><?php echo e(date('h:m A',strtotime($FreeTime->startTime))); ?></td>
                                                    <td><?php echo e(date('h:m A',strtotime($FreeTime->endTime))); ?></td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <div class="spacer-xs"></div>

                                </div> <!-- end .profile-skills-wrapper -->


                            </div> <!-- end .profile-wrapper -->
                        </div> <!-- end .profile-info -->

                        <div class="divider"></div>

                        <!-- end .profile-wrapper -->
                    </div> <!-- end #profile-tab -->

                </div> <!-- end .right-side-content -->

            </div> <!-- end .container -->
        </div> <!-- end .inner -->
    </div> <!-- end .section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>