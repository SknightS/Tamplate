<?php $__env->startSection('emp-contant'); ?>
    
    <style>
        .ui-autocomplete-input {
            border: none;
            font-size: 14px;
            width: 300px;
            height: 24px;
            margin-bottom: 5px;
            padding-top: 2px;
            border: 1px solid #DDD !important;
            padding-top: 0px !important;
            z-index: 1511;
            position: relative;
        }
        .ui-menu .ui-menu-item a {
            font-size: 12px;
        }
        .ui-autocomplete {
            position: absolute;
            top: 0;
            left: 2px;
            z-index: 1510 !important;
            float: left;
            display: none;
            min-width: 160px;
            width: 160px;
            padding: 8px 0;
            margin: 8px 0 0 0;
            list-style: none;
            background-color: #ffffff;
            border-color: #ccc;
            border-color: rgba(0, 0, 0, 0.2);
            border-style: solid;
            border-width: 1px;
            -webkit-border-radius: 2px;
            -moz-border-radius: 2px;
            border-radius: 2px;
            -webkit-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
            -moz-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
            -webkit-background-clip: padding-box;
            -moz-background-clip: padding;
            background-clip: padding-box;
            *border-right-width: 2px;
            *border-bottom-width: 2px;
        }
        .ui-menu-item > a.ui-corner-all {
            display: block;
            padding: 3px 15px;
            clear: both;
            font-weight: normal;
            line-height: 18px;
            color: #555555;
            white-space: nowrap;
            text-decoration: none;
        }
        .ui-state-hover, .ui-state-active {
            color: #ffffff;
            text-decoration: none;
            background-color: #0088cc;
            border-radius: 0px;
            -webkit-border-radius: 0px;
            -moz-border-radius: 0px;
            background-image: none;
        }

    </style>
    <div class="profile-badge"><h6>My resume</h6></div>
    <div class="profile-wrapper">

        <div class="profile-info profile-section flex no-column no-wrap">

            <div class="profile-picture">
                <?php if($candidateInfo->image != null): ?>
                    <img src="<?php echo e(url('public/employeeImages/thumb/'.$candidateInfo->image)); ?>" height="116px" width="116px" alt="candidate-picture" class="img-responsive">
                <?php else: ?>
                    <img src="<?php echo e(url('public/employeeImages/dummy.jpg')); ?>" height="116px" width="116px" alt="candidate-picture" class="img-responsive">
                <?php endif; ?>
            </div> <!-- end .user-picture -->
            <div class="profile-meta">
                <h4 class="dark"><?php echo e($candidateInfo->name); ?><span><a style="cursor: pointer" onclick="editCandidate()"><i class="ion-edit"></i></a></span></h4>
                
                <p><?php echo e($candidateInfo->professionTitle); ?></p>
                <div class="profile-contact flex items-center no-wrap no-column">
                    <?php if($employeeAddress!=null): ?>
                        <?php $__currentLoopData = $employeeAddress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h6 class="contact-location"><?php echo e($address->addresscol); ?>,<span><?php echo e($address->city); ?>, <?php echo e($address->state); ?></span></h6>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <h6 class="contact-location"><span></span></h6>
                    <?php endif; ?>
                    <h6 class="contact-phone"><?php echo e($candidateInfo->phone); ?></h6>
                    <h6 class="contact-email"><?php echo e($candidateInfo->email); ?></h6>
                </div> <!-- end .profile-contact -->
                <div>
                    
                    <ul class="list-unstyled social-icons flex no-column">
                        <?php $__currentLoopData = $socialLink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialLinks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e($socialLinks->link); ?>"><?php echo e($socialLinks->link); ?></a>
                                
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                    </ul> <!-- end .social-icons -->
                </div>
            </div> <!-- end .profile-meta -->
        </div> <!-- end .profile-info -->

        <div class="divider"></div>

        <div class="profile-about profile-section">
            <h3 class="dark profile-title">About me<span><a style="cursor: pointer" onclick="editCandidateAboutMe()"><i class="ion-edit"></i></a></span></h3>
            <p><?php echo e($candidateInfo->aboutme); ?></p>
        </div> <!-- end .profile-about -->

        <div class="divider"></div>

        <div id="workExperience" class="profile-experience-wrapper profile-section">
            <h3 class="dark profile-title">Work experience<span><a style="cursor: pointer"  onclick="addCandidateWorkExperience()"><i class="ion-plus"></i></a></span></h3>
            <?php $__currentLoopData = $workExperience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workingExp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="profile-experience flex space-between no-wrap no-column">
                    <div class="profile-experience-left">
                        <h5 class="profile-designation dark"><?php echo e($workingExp->postName); ?><span><a data-panel-id="<?php echo e($workingExp->workExperienceId); ?>" onclick="editCandidateWorkExperience(this)" style="cursor: pointer;"><i  class="ion-edit"></i></a><a class="deleteIcon" data-panel-id="<?php echo e($workingExp->workExperienceId); ?>"onclick="deleteWorkExperince(this)" style="cursor: pointer;" onclick=""><i class="ion-android-delete"></i></a></span></h5>
                        <h5 class="profile-company dark"><?php echo e($workingExp->comapnyName); ?></h5>
                        <p class="small ultra-light"><?php echo e($workingExp->duration); ?></p>
                        <p><?php echo e($workingExp->description); ?></p>
                        
                    </div> <!-- end .profile-experience-left -->
                    
                    
                    
                </div> <!-- end .profile-experience -->
                <div class="spacer-md"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> <!-- end .profile-experience-wrapper -->

        <div class="divider"></div>

        <div id="Education" class="profile-education-wrapper profile-section">
            <h3 class="dark profile-title">Education<span><a style="cursor: pointer" onclick="addCandidateEducation()"><i class="ion-plus"></i></a></span></h3>
            <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="profile-education">
                    <h5 class="dark"><?php echo e($edu->schoolName); ?>&nbsp;<span><a style="cursor: pointer;" data-panel-id="<?php echo e($edu->educationId); ?>" onclick="editCandidateEducation(this)"><i class="ion-edit"></i></a><a  style="cursor: pointer;" data-panel-id="<?php echo e($edu->educationId); ?>" onclick="deleteEducation(this)"><i class="ion-android-delete"></i></a></span></h5>
                    <p><?php echo e($edu->degreeName); ?></p>
                    <p class="ultra-light"><?php echo e($edu->startDate); ?> - <?php if($edu->currentlyRunning=='0'): ?><?php echo e($edu->endDate); ?><?php else: ?><?php echo e("Currenty Running"); ?><?php endif; ?></p>
                </div> <!-- end .profile-education -->
                <div class="spacer-md"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div> <!-- end .profile-education-wrapper -->

        <div class="divider"></div>

        <div id="Skill" class="profile-skills-wrapper profile-section">
            <h3 class="dark profile-title">Summary skill<span><a style="cursor: pointer" onclick="addCandidateSkill()"><i class="ion-plus"></i></a></span></h3>
            <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personalSkill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="progress-wrapper flex space-between items-center no-wrap">
                    <h6 class="progress-skill"><?php echo e($personalSkill->skillName); ?></h6>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo e($personalSkill->percentage); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($personalSkill->percentage); ?>%;">
                        </div> <!-- end .progress-bar -->
                    </div> <!-- end .progress -->
                    <h6 class="percentage"><span class="countTo" data-from="0" data-to="<?php echo e($personalSkill->percentage); ?>"><?php echo e($personalSkill->percentage); ?></span>%</h6>
                    <span><a style="cursor: pointer;" data-panel-id="<?php echo e($personalSkill->id); ?>" onclick="editSkill(this)"><i class="ion-edit"></i></a><a  style="cursor: pointer;" data-panel-id="<?php echo e($personalSkill->id); ?>" onclick="deleteSkill(this)"><i class="ion-android-delete"></i></a></span>
                </div> <!-- end .progress-wrapper -->

                <div class="spacer-xs"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <input type="text" id="test">
        </div> <!-- end .profile-skills-wrapper -->

        <div class="divider"></div>

        <div id="FreeTime" class="profile-skills-wrapper profile-section">
            <h3 class="dark profile-title">Free Time<span><a style="cursor: pointer" onclick="addCandidateFreeTime()"><i class="ion-plus"></i></a></span></h3>

            <div class="col-md-12">
                <table class="table table-responsive table-bordered">
                    <thead>
                    <th>Day</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                    <th>Action</th>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $FreeTimeInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $FreeTime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($FreeTime->day); ?></td>
                            <td><?php echo e(date('h:m A',strtotime($FreeTime->startTime))); ?></td>
                            <td><?php echo e(date('h:m A',strtotime($FreeTime->endTime))); ?></td>
                            <td><a style="cursor: pointer;" data-panel-id="<?php echo e($FreeTime->id); ?>" onclick="editFreeTime(this)"><i class="ion-edit"></i></a><a  style="cursor: pointer;" data-panel-id="<?php echo e($FreeTime->id); ?>" onclick="deleteFreeTime(this)"><i class="ion-android-delete"></i></a></td>


                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>





                <div class="spacer-xs"></div>


            </div> <!-- end .profile-skills-wrapper -->

        </div> <!-- end .profile-wrapper -->

        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('foot-js'); ?>
            <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
            <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />


            <script>
                $( function() {
                    var availableTags = [
                        "Altstadt",
                        "Altstadt",
                        "Bahnhofsviertel",
                        "Bergen-Enkheim",
                        "Bergen-Enkheim",
                        "Berkersheim",];

                    $( "#test" ).autocomplete({
                        source: availableTags
                    });
                } );


                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $(document).ready(function(){
                    <?php if(Session::has('success_msg')): ?>
                    $.alert({
                        title: 'Success!',
                        type: 'green',
                        content: '<?php echo e(Session::get('success_msg')); ?>',
                        buttons: {
                            tryAgain: {
                                text: 'Ok',
                                btnClass: 'btn-green',
                                action: function () {
                                }
                            }
                        }
                    });
                    <?php endif; ?>
                });
                function editCandidate() {
                    var id= '<?php echo e($candidateInfo->candidateId); ?>';
                    var name = '<?php echo e($candidateInfo->name); ?>';
                    var professionTitle = '<?php echo e($candidateInfo->professionTitle); ?>';
                    var phone = '<?php echo e($candidateInfo->phone); ?>';
                    var email = '<?php echo e($candidateInfo->email); ?>';
                    var addressId = '<?php echo e($candidateInfo->address_addressId); ?>';
                    $.ajax({
                        type: "POST",
                        url: '<?php echo e(route('employee.showInfo')); ?>',
                        data: {name:name,profession:professionTitle,phone:phone,email:email,id:id,address:addressId},
                        success: function(data){
                            $('.modal-body').html(data);
                            $('#myModalLabel').html("Edit-Candidate Info!");
                            $('#myModal').modal({show:true});
                        },
                    });
                }
                function editCandidateAboutMe() {
                    var id= '<?php echo e($candidateInfo->candidateId); ?>';
                    $.ajax({
                        type: "POST",
                        url: '<?php echo e(route('employee.editCandidateAboutMe')); ?>',
                        data: {id:id},
                        success: function(data){
                            $('.modal-body').html(data);
                            $('#myModal').modal({show:true});
                        },
                    });
                }
                function deleteWorkExperince(x) {
                    $.confirm({
                        title: 'Confirm!',
                        content: 'Are you sure To delete this Work-Experience?',
                        icon: 'fa fa-warning',
                        type: 'red',
                        typeAnimated: true,
                        buttons: {
                            tryAgain: {
                                text: 'Yes',
                                btnClass: 'btn-red',
                                action: function(){
                                    var id = $(x).data('panel-id');
                                    $.ajax({
                                        type: "POST",
                                        url: '<?php echo e(route('employee.deleteWorkExperience')); ?>',
                                        data: {id: id},
                                        success: function (data) {
                                            $.alert({
                                                title: 'Success!',
                                                type: 'green',
                                                content: 'Work-Experience Deleted successfully',
                                                buttons: {
                                                    tryAgain: {
                                                        text: 'Ok',
                                                        btnClass: 'btn-green',
                                                        action: function () {
                                                            $('#workExperience').load(document.URL +  ' #workExperience');
                                                        }
                                                    }
                                                }
                                            });
                                        },
                                    });
                                }
                            },
                            No: function () {
                            },
                        }
                    });
                }
                function deleteEducation(x) {
                    $.confirm({
                        title: 'Confirm!',
                        content: 'Are you sure To delete this Education?',
                        icon: 'fa fa-warning',
                        type: 'red',
                        typeAnimated: true,
                        buttons: {
                            tryAgain: {
                                text: 'Yes',
                                btnClass: 'btn-red',
                                action: function(){
                                    var id = $(x).data('panel-id');
                                    $.ajax({
                                        type: "POST",
                                        url: '<?php echo e(route('employee.deleteEducation')); ?>',
                                        data: {id: id},
                                        success: function (data) {
                                            $.alert({
                                                title: 'Success!',
                                                type: 'green',
                                                content: 'Education Deleted successfully',
                                                buttons: {
                                                    tryAgain: {
                                                        text: 'Ok',
                                                        btnClass: 'btn-green',
                                                        action: function () {
                                                            $('#Education').load(document.URL +  ' #Education');
                                                        }
                                                    }
                                                }
                                            });
                                        },
                                    });
                                }
                            },
                            No: function () {
                            },
                        }
                    });
                }
                function addCandidateWorkExperience() {
                    var id= '<?php echo e($candidateInfo->candidateId); ?>';
                    $.ajax({
                        type: "POST",
                        url: '<?php echo e(route('employee.addCandidateWorkExperience')); ?>',
                        data: {id:id},
                        success: function(data){
                            $('.modal-body').html(data);
                            $('#myModalLabel').html("Add-Candidate Info! : Work-Experience");
                            $('#myModal').modal({show:true});
                        },
                    });
                }
                function editCandidateWorkExperience(x) {
                    var id = $(x).data('panel-id');
                    $.ajax({
                        type: "POST",
                        url: '<?php echo e(route('employee.editCandidateWorkExperience')); ?>',
                        data: {id:id},
                        success: function(data){
                            $('.modal-body').html(data);
                            $('#myModalLabel').html("Edit-Candidate Info! : Work-Experience");
                            $('#myModal').modal({show:true});
                        },
                    });
                }
                function addCandidateEducation() {
                    var id= '<?php echo e($candidateInfo->candidateId); ?>';
                    $.ajax({
                        type: "POST",
                        url: '<?php echo e(route('employee.addEducation')); ?>',
                        data: {id:id},
                        success: function(data){
                            $('.modal-body').html(data);
                            $('#myModalLabel').html("Add-Candidate Info! : Education");
                            $('#myModal').modal({show:true});
                        },
                    });
                }
                function editCandidateEducation(x) {
                    var id = $(x).data('panel-id');
                    $.ajax({
                        type: "POST",
                        url: '<?php echo e(route('employee.editCandidateEducation')); ?>',
                        data: {id:id},
                        success: function(data){
                            $('.modal-body').html(data);
                            $('#myModalLabel').html("Edit-Candidate Info! : Education");
                            $('#myModal').modal({show:true});
                        },
                    });
                }
                function addCandidateSkill() {
                    var id= '<?php echo e($candidateInfo->candidateId); ?>';
                    $.ajax({
                        type: "POST",
                        url: '<?php echo e(route('employee.addCandidateSkill')); ?>',
                        data: {id:id},
                        success: function(data){
                            $('.modal-body').html(data);
                            $('#myModalLabel').html("Add-Candidate Info! : Skill");
                            $('#myModal').modal({show:true});
                            //  console.log(data);
                        },
                    });
                }
                function editSkill(x) {
                    var id = $(x).data('panel-id');
                    $.ajax({
                        type: "POST",
                        url: '<?php echo e(route('employee.editSkill')); ?>',
                        data: {id:id},
                        success: function(data){
                            $('.modal-body').html(data);
                            $('#myModalLabel').html("Edit-Candidate Info! : Skill");
                            $('#myModal').modal({show:true});
                        },
                    });
                }
                function deleteSkill(x) {
                    $.confirm({
                        title: 'Confirm!',
                        content: 'Are you sure To delete this Skill?',
                        icon: 'fa fa-warning',
                        type: 'red',
                        typeAnimated: true,
                        buttons: {
                            tryAgain: {
                                text: 'Yes',
                                btnClass: 'btn-red',
                                action: function(){
                                    var id = $(x).data('panel-id');
                                    $.ajax({
                                        type: "POST",
                                        url: '<?php echo e(route('employee.deleteSkill')); ?>',
                                        data: {id: id},
                                        success: function (data) {
                                            $.alert({
                                                title: 'Success!',
                                                type: 'green',
                                                content: 'Skill Deleted successfully',
                                                buttons: {
                                                    tryAgain: {
                                                        text: 'Ok',
                                                        btnClass: 'btn-green',
                                                        action: function () {
                                                            $('#Skill').load(document.URL +  ' #Skill');
                                                        }
                                                    }
                                                }
                                            });
                                        },
                                    });
                                }
                            },
                            No: function () {
                            },
                        }
                    });
                }
                function addCandidateFreeTime() {
                    var id= '<?php echo e($candidateInfo->candidateId); ?>';
                    $.ajax({
                        type: "POST",
                        url: '<?php echo e(route('employee.addCandidateFreeTime')); ?>',
                        data: {id:id},
                        success: function(data){
                            $('.modal-body').html(data);
                            $('#myModalLabel').html("Add-Candidate Info! : Free Time");
                            $('#myModal').modal({show:true});
                        },
                    });
                }
                function editFreeTime(x) {
                    var id = $(x).data('panel-id');
                    $.ajax({
                        type: "POST",
                        url: '<?php echo e(route('employee.editFreeTime')); ?>',
                        data: {id:id},
                        success: function(data){
                            $('.modal-body').html(data);
                            $('#myModalLabel').html("Edit-Candidate Info! : Free Time");
                            $('#myModal').modal({show:true});
                        },
                    });
                }
                function deleteFreeTime(x) {
                    $.confirm({
                        title: 'Confirm!',
                        content: 'Are you sure To delete this Free Time?',
                        icon: 'fa fa-warning',
                        type: 'red',
                        typeAnimated: true,
                        buttons: {
                            tryAgain: {
                                text: 'Yes',
                                btnClass: 'btn-red',
                                action: function(){
                                    var id = $(x).data('panel-id');
                                    $.ajax({
                                        type: "POST",
                                        url: '<?php echo e(route('employee.deleteFreeTime')); ?>',
                                        data: {id: id},
                                        success: function (data) {
                                            $.alert({
                                                title: 'Success!',
                                                type: 'green',
                                                content: 'Free Time Deleted successfully',
                                                buttons: {
                                                    tryAgain: {
                                                        text: 'Ok',
                                                        btnClass: 'btn-green',
                                                        action: function () {
                                                            $('#FreeTime').load(document.URL +  ' #FreeTime');
                                                        }
                                                    }
                                                }
                                            });
                                        },
                                    });
                                }
                            },
                            No: function () {
                            },
                        }
                    });
                }
            </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employee.employeDashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>