<div class="top flex space-between no-wrap items-center">
    <h6>showing
        <span><?php echo e(($allCandidates->currentpage()-1)*$allCandidates->perpage()+1); ?>

            - <?php echo e((($allCandidates->currentpage()-1)*$allCandidates->perpage())+$allCandidates->count()); ?>

                                </span>of
        <span><?php echo e($allCandidates->total()); ?></span>candidates</h6>
    <div class="spacer-xs-m"></div>
    <div class="sort-by dropdown flex no-wrap no-column items-center">
        <h6>sort by</h6>
        <button class="button dropdown-toggle" type="button" id="sort-by" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Default
            <i class="ion-ios-arrow-down"></i>
        </button>

        <ul class="dropdown-menu" aria-labelledby="sort-by">
            <li><a href="#">Featured</a></li>
            <li><a href="#">Top candidates</a></li>
            <li><a href="#">Price, high to low</a></li>
            <li><a href="#">Alphabetically, A-Z</a></li>
            <li><a href="#">Alphabetically, Z-A</a></li>
            <li><a href="#">Best sellers</a></li>
        </ul> <!-- end .dropdown-menu -->
    </div> <!-- end .sort-by -->
</div> <!-- end .top -->


<?php $__currentLoopData = $allCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="candidates-list">
        <div class="candidate flex no-wrap no-column">

            <div class="candidate-image">
                <?php if(!empty($candidates->image)): ?>
                    <img src="<?php echo e('public/employeeImages'."/".$candidates->image); ?>" alt="candidate-image" class="img-responsive">
                <?php else: ?>
                    <img src="<?php echo e('public/employeeImages/dummy.jpg'); ?>" alt="candidate-image" class="img-responsive">
                <?php endif; ?>
            </div> <!-- end .candidate-image -->

            <div class="candidate-info">
                <a href="<?php echo e(route('candidatedetails',$candidates->candidateId)); ?>"> <h4 class="candidate-name"><?php echo e($candidates->name); ?></h4>
                    <h5 class="candidate-designation"><?php echo e($candidates->professionTitle); ?></h5>
                </a>

                <p class="candidate-description ultra-light">
                    <?php echo e($candidates->aboutme); ?>

                </p>

                <div class="candidate-info-bottom flex no-column items-center">

                    
                    
                    


                    <h6 class="contact-location"><?php echo e($candidates->addresscol); ?>,<span><?php echo e($candidates->city); ?>, <?php echo e($candidates->state); ?></span></h6>&nbsp;&nbsp;


                    <h6 class="hourly-rate"><span>$45</span>/Hour</h6>

                    <ul class="list-unstyled candidate-skills flex no-column items-center">

                        <?php $__currentLoopData = $allSkill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personalSkill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($personalSkill->candidateId==$candidates->candidateId): ?>
                                <li><a href="#" class="button"><?php echo e($personalSkill->skillName); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                


                    </ul> <!-- end .candiate-skills -->
                </div> <!-- end .candidate-info-bottom -->
            </div> <!-- end .candidate-info -->
        </div> <!-- end .candidate -->
    </div> <!-- end .candidates-list -->

    <div class="spacer-xs"></div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<div class="jobpress-custom-pager list-unstyled flex space-center no-column items-center">

    <?php if($allCandidates->currentPage()!= 1): ?>
        <a data-id="<?php echo e($allCandidates->previousPageUrl()); ?>" href="javascript:void(0)" class="button pagiNextPrevBtn"><i class="ion-ios-arrow-left"></i>Prev</a>
    <?php endif; ?>
    <ul class="list-unstyled flex no-column items-center pagination">
        <?php for($i=$allCandidates->perPage(); $i <= $allCandidates->total();$i=($i+$allCandidates->perPage())): ?>
            <li ><a href="<?php echo e($allCandidates->url($i)); ?>"><?php echo e($i); ?></a></li>
        <?php endfor; ?>
    </ul>
    <?php if($allCandidates->lastPage()!=$allCandidates->currentPage()): ?>
        <a data-id="<?php echo e($allCandidates->nextPageUrl()); ?>"href="javascript:void(0)"  class="button pagiNextPrevBtn">Next<i class="ion-ios-arrow-right"></i></a>
    <?php endif; ?>

</div> <!-- end .jobpress-custom-pager -->

<script>
    $(".pagiNextPrevBtn").on("click",function() {

        var page=$(this).data('id').split('page=')[1];

        getData(page)

    });
</script>