@extends('main')

@section('content')
<!-- Responsive Menu -->
<div class="responsive-menu">
    <a href="#" class="responsive-menu-close"><i class="ion-android-close"></i></a>
    <nav class="responsive-nav"></nav> <!-- end .responsive-nav -->
</div> <!-- end .responsive-menu -->

<!-- Breadcrumb Bar -->
<div class="section breadcrumb-bar solid-blue-bg">
    <div class="inner">
        <div class="container">
            <div class="breadcrumb-menu flex items-center no-column">
                <img src="images/candidate01.jpg" alt="candidate-picture" class="img-responsive">
                <div class="breadcrumb-info-dashboard">
                    <h2>Mark anderson</h2>
                    <h4>UI/UX Designer</h4>

                </div> <!-- end .candidate-info -->
            </div> <!-- end .breadcrumb-menu -->
        </div> <!-- end .container -->
    </div> <!-- end .inner -->
</div> <!-- end .section -->

<!-- Employer Dashboard -->
<div class="section employer-dashboard-content solid-light-grey-bg">
    <div class="inner">
        <div class="container">

            <div class="right-side-content ">

                <div id="profile" class="tab-pane  fade in active">

                    <div class="profile-wrapper fade in active">


                            <div class="profile-badge"><h6>My resume</h6></div>
                            <div class="profile-wrapper">

                                <div class="profile-info profile-section flex no-column no-wrap">
                                    <div class="profile-picture">
                                        <img src="images/candidate01.jpg" alt="candidate-picture" class="img-responsive">
                                    </div> <!-- end .user-picture -->
                                    <div class="profile-meta">
                                        <h4 class="dark">Mark anderson</h4>
                                        <p>UI/UX Designer</p>
                                        <div class="profile-contact flex items-center no-wrap no-column">
                                            <h6 class="contact-location">Manhattan,<span>NYC, USA</span></h6>
                                            <h6 class="contact-phone">(+01)-212-322-5732</h6>
                                            <h6 class="contact-email">mark.anderson@gmail.com</h6>
                                        </div> <!-- end .profile-contact -->
                                        <ul class="list-unstyled social-icons flex no-column">
                                            <li><a href="#0"><i class="ion-social-twitter"></i></a></li>
                                            <li><a href="#0"><i class="ion-social-facebook"></i></a></li>
                                            <li><a href="#0"><i class="ion-social-instagram"></i></a></li>
                                        </ul> <!-- end .social-icons -->
                                    </div> <!-- end .profile-meta -->
                                </div> <!-- end .profile-info -->

                                <div class="divider"></div>

                                <div class="profile-about profile-section">
                                    <h3 class="dark profile-title">About me<span><i class="ion-edit"></i></span></h3>
                                    <p>Nullam semper erat arcu, ac tincidunt sem venenatis vel. Curabitur at dolor ac ligula fermentum euismod ac ullamcorper nulla. Integer blandit ultricies aliquam. Pellentesque quis dui varius, dapibus velit id, iaculis ipsum. Morbi ac eros feugiat, lacinia elit ut, elementum turpis. Curabitur justo sapien, tempus sit amet rutrum eu, commodo eu lacus. Morbi in ligula nibh. Maecenas ut mi at odio hendrerit eleif end tempor vitae augue. Fusce eget arcu et nibh dapibus maximus consectetur in est. Sed iaculis luctus nibh sed venenatis.</p>
                                </div> <!-- end .profile-about -->

                                <div class="divider"></div>

                                <div class="profile-experience-wrapper profile-section">
                                    <h3 class="dark profile-title">Work experience<span><i class="ion-edit"></i></span></h3>
                                    <div class="profile-experience flex space-between no-wrap no-column">
                                        <div class="profile-experience-left">
                                            <h5 class="profile-designation dark">UI/UX designer</h5>
                                            <h5 class="profile-company dark">Banana inc.</h5>
                                            <p class="small ultra-light">May 2015 - Present (1.5 years)</p>
                                            <p>Nulla molestie sed lorem non suscipit. Morbi imperdiet ex sit amet tortor faucibus ultricies. Fusce tincidunt elementum imperdiet.</p>
                                            <h6 class="projects-count">4 projects</h6>
                                        </div> <!-- end .profile-experience-left -->
                                        <div class="profile-experience-right">
                                            <img src="images/company-logo-big01.jpg" alt="company-logo" class="img-responsive">
                                        </div> <!-- end .profile-experience-right -->
                                    </div> <!-- end .profile-experience -->
                                    <div class="spacer-md"></div>
                                    <div class="profile-experience flex space-between no-wrap no-column">
                                        <div class="profile-experience-left">
                                            <h5 class="profile-designation dark">UI Designer</h5>
                                            <h5 class="profile-company dark">Whale creative</h5>
                                            <p class="small ultra-light">May 2013 - May 2015 (over 2 years)</p>
                                            <p>Nulla molestie sed lorem non suscipit. Morbi imperdiet ex sit amet tortor faucibus ultricies. Fusce tincidunt elementum imperdiet.</p>
                                            <h6 class="projects-count">4 projects</h6>
                                        </div> <!-- end .profile-experience-left -->
                                        <div class="profile-experience-right">
                                            <img src="images/company-logo-big05.jpg" alt="company-logo" class="img-responsive">
                                        </div> <!-- end .profile-experience-right -->
                                    </div> <!-- end .profile-experience -->
                                </div> <!-- end .profile-experience-wrapper -->

                                <div class="divider"></div>

                                <div class="profile-education-wrapper profile-section">
                                    <h4 class="dark profile-title">Education<span><i class="ion-edit"></i></span></h4>
                                        <div class="profile-education">
                                            <h5 class="dark">Massachusetts Institute of Technology</h5>
                                            <p>Bachelor of Computer Science</p>
                                            <p class="ultra-light">2010-2014</p>
                                        </div> <!-- end .profile-education -->
                                        <div class="spacer-md"></div>
                                        <div class="profile-education">
                                            <h5 class="dark">School of Arts & Sciences of Stanford University</h5>
                                            <p>Bachelor of Arts & Sciences</p>
                                            <p class="ultra-light">2008-2012</p>
                                        </div> <!-- end .profile-education -->
                                </div> <!-- end .profile-education-wrapper -->

                                <div class="divider"></div>

                                <div class="profile-skills-wrapper profile-section">
                                    <h3 class="dark profile-title">Summary skill<span><i class="ion-edit"></i></span></h3>
                                    <div class="progress-wrapper flex space-between items-center no-wrap">
                                        <h6 class="progress-skill">HTML</h6>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%;">
                                            </div> <!-- end .progress-bar -->
                                        </div> <!-- end .progress -->
                                        <h6 class="percentage"><span class="countTo" data-from="0" data-to="90">90</span>%</h6>
                                    </div> <!-- end .progress-wrapper -->
                                    <div class="spacer-xs"></div>
                                    <div class="progress-wrapper flex space-between items-center no-wrap">
                                        <h6 class="progress-skill">WordPress</h6>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%;">
                                            </div> <!-- end .progress-bar -->
                                        </div> <!-- end .progress -->
                                        <h6 class="percentage"><span class="countTo" data-from="0" data-to="80">80</span>%</h6>
                                    </div> <!-- end .progress-wrapper -->
                                    <div class="spacer-xs"></div>
                                    <div class="progress-wrapper flex space-between items-center no-wrap">
                                        <h6 class="progress-skill">PS</h6>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
                                            </div> <!-- end .progress-bar -->
                                        </div> <!-- end .progress -->
                                        <h6 class="percentage"><span class="countTo" data-from="0" data-to="60">60</span>%</h6>
                                    </div> <!-- end .progress-wrapper -->
                                    <div class="spacer-xs"></div>
                                    <div class="progress-wrapper flex space-between items-center no-wrap">
                                        <h6 class="progress-skill">AI</h6>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%;">
                                            </div> <!-- end .progress-bar -->
                                        </div> <!-- end .progress -->
                                        <h6 class="percentage"><span class="countTo" data-from="0" data-to="90">90</span>%</h6>
                                    </div> <!-- end .progress-wrapper -->
                                </div> <!-- end .profile-skills-wrapper -->

                            </div> <!-- end .profile-wrapper -->
                        </div> <!-- end .profile-info -->

                        <div class="divider"></div>

                     <!-- end .profile-wrapper -->
                </div> <!-- end #profile-tab -->

            </div> <!-- end .right-side-content -->

        </div> <!-- end .container -->
    </div> <!-- end .inner -->
</div> <!-- end .section -->
@endsection