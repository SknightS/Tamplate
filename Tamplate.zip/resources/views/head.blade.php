<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Staff Network</title>

    <!-- CSS -->
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <!-- Ionicons -->
    <link href="{{url('public/fonts/ionicons/css/ionicons.min.css')}}" rel="stylesheet">
    <!-- Owl Carousel -->
    <link href="{{url('public/css/owl.carousel.css')}}" rel="stylesheet">
    <link href="{{url('public/css/owl.theme.default.css')}}" rel="stylesheet">
    <!-- Animate.css -->
    <link href="{{url('public/css/animate.min.css')}}" rel="stylesheet">
    <!--Magnific Popup -->
    <link href="{{url('public/css/magnific-popup.css')}}" rel="stylesheet">
    <!--Tagsinput CSS -->
    <link href="{{url('public/css/tagsinput.css')}}" rel="stylesheet">
    <!-- Style.css -->
    <link href="{{url('public/css/style.css')}}" rel="stylesheet">
    <link href="{{url('public/css/grasshopper.css')}}" rel="stylesheet">

    <!-- jQuery -->
    <!--<script src="js/jquery-3.1.1.min.js"></script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">



</head>